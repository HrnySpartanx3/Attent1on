//basic init stuff, nothing special
const canv=document.getElementById('view') as HTMLCanvasElement;
const app=new TypingGame(canv);

function init(){
    window.addEventListener('keydown',(e:KeyboardEvent)=>{app.updateKeyDown(e)});
    window.addEventListener('keyup',(e:KeyboardEvent)=>{app.updateKeyUp(e)});
    
    for(const c of supportedChars)app.res.addImage('./images/c'+c+'.png',supportedCharSize,supportedCharSize);
    
}