const supportedCharSize = 10;//pxs
const supportedChars = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','qm'];

/**
 * get rounded random nr between min and max, both including!
 * @param min 
 * @param max 
 * @returns 
 */
function getRandR(min:number,max:number){
    return Math.round(Math.random()*(max-min)+min);
}