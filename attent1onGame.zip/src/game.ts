class CharSymbol{
    char:string;
    img:HTMLImageElement;
    constructor(char:string,img:HTMLImageElement){
        this.char=char;this.img=img;
    }
}
class TypingGame{
    //drawing and stuff
    elemCanv: HTMLCanvasElement;
    ctx: CanvasRenderingContext2D;
    //event handling
    keysPress: {[keyName:string]:boolean}; //keys hold atm are true, otherwise false or not in the map
    viewXOff: number; //position offset of canvas in document 
	viewYOff: number;
    //resource handling
    res:Res;
    //state
    state: 0 | 1;
    /*0: init-state (add resources,..), 1: ingame-state (all resources loaded) */
    timer: number; // timer 
	
	//game related stuff
	heading:string; //the to-be-displayed current text
	subheadings:string[]; //textlines under the heading
	markedHeadingParts:number[]; //marked/emphasized parts, even:startidx inc, odd:endidx,excluding
	input:string; //the curr input in building progress
	supportedInputChars:string[];
	module: Typer;
	symbolLookup:{[id:string]:CharSymbol};
	charSizeInput:number; //abs input text size
	charSizeHeadingMin:number; //abs min heading text size
	charSizeSpacing:number; //relative spacing size between chars
	charPosInput:number; //abs input y position
	charMinMargin:number; //abs min remaining space between screen border and contents
	

    constructor(canv: HTMLCanvasElement){
        //init events
        this.keysPress = {};
		this.viewXOff = canv.offsetLeft; //element offset
		this.viewYOff = canv.offsetTop;
	
        //init screen
        this.elemCanv= canv;
        this.ctx = canv.getContext("2d") as CanvasRenderingContext2D;
        this.elemCanv.width=window.innerWidth;
        this.elemCanv.height=window.innerHeight;
		this.ctx.imageSmoothingEnabled = false; //canvas image px effect
		
		//dont get fucked with a white screen
		this.ctx.fillStyle='black';
		this.ctx.fillRect(0,0,window.innerWidth,window.innerHeight);

        //init state
		this.res=new Res();
        this.state=0;
		
		//game related
		this.symbolLookup = {};
		this.supportedInputChars=[];
		const nonInputChars= ['qm'];
		for(const c of supportedChars)if(nonInputChars.indexOf(c)==-1)this.supportedInputChars.push(c);
		this.input = '';
		this.heading = 'some random stuff here lolz brrrrr?';
		this.subheadings=[];
		this.markedHeadingParts=[];
		this.module = new Typer(this);
		this.charSizeInput = this.getAbsW(0.02);
		this.charSizeHeadingMin = this.getAbsW(0.027); 
		this.charSizeSpacing = 0.1;
		this.charPosInput = this.getAbsH(0.8);
		this.charMinMargin = this.getAbsW(0.02);
		
		//start
        this.timer = setInterval(() => this.updateInit(),25); //update the loading screen
        setTimeout(() => this.start(),5000); //just to make sure nothing freezes
    }
    
	/**
	 * get px from view width relative
	 * @param r in range [0,1]
	 * @returns px
	 */
	getAbsW(r:number){
		return Math.round(r*this.elemCanv.width);
	}
	/**
	 * get px from view height relative r
	 * @param r in range [0,1]
	 * @returns px
	 */
	getAbsH(r:number){
		return Math.round(r*this.elemCanv.height);
	}
	
	/**
	 * fires when all resources have been loaded
	 */
    start():void{
		if(this.state == 1)return; //timeout or other
		console.log("start"); 
		//reset load screen
		this.state=1;
		clearInterval(this.timer);

		//game specific
		for(const c of supportedChars){
			const i:HTMLImageElement = this.res.getImg('c'+c) as HTMLImageElement;
			let char:string =c;
			switch(c){
				case 'qm':char='?'; break;
			}
			this.symbolLookup[char]=new CharSymbol(char,i);
		}
		this.module.init();
    }
    
	// concept of event & event inner state changing
    updateKeyDown(e: KeyboardEvent){ //type key down
        this.keysPress[e.key as string] = true;
		this.updateInGame(e.key);
		this.draw();
    }
	updateKeyUp(e: KeyboardEvent){ //type key up
        this.keysPress[e.key as string] = false;
    }
    //called each frame, checks if all resources are loaded
    updateInit():void{
        const state = this.res.getState();
		console.log('loading state: '+this.res.getState());
		if(state == 100){this.start();}
    }
	updateInGame(key: string){
		this.res.playSound('kb'+getRandR(1,supportedKBSounds));
		if(key === 'Enter'){
			this.module.input(this.input);
			this.input='';
		}else
		if(key === 'Backspace'){
			if(this.input.length > 0)
			this.input = this.input.slice(0,this.input.length-1);
		} else 
		if(key === ' '){
			this.input +=' ';
		} else if(this.supportedInputChars.indexOf(key) > -1){
			this.input += key;
		}
	}
	output(heading:string,subheadings:string[],markedParts:number[]){
		this.heading = heading;
		this.subheadings = subheadings;
		this.markedHeadingParts=markedParts;
		this.draw();
	}
	
	getTextWidth(textLength:number,charSize:number){
		const spacing = Math.round(this.charSizeSpacing * charSize);
		return spacing*(textLength-1)+textLength*charSize;
	}
	drawCenterText(txt:string,charSize:number,y:number,color:string,markedParts?:number[]){
		const spacing = Math.round(this.charSizeSpacing * charSize);
		const w = this.getTextWidth(txt.length,charSize);
		const x = this.getAbsW(0.5)-Math.round(0.5*w);
		let unMarkedParts:number[] = [0,txt.length];
		if(markedParts){
			unMarkedParts = [];
			let lastI = 0;
			for(let i=0;i<markedParts.length;i+=2){
				const markedPartStart = markedParts[i];
				const markedPartEnd = markedParts[i+1];
				if(markedPartStart - lastI > 0){
					unMarkedParts.push(lastI);
					unMarkedParts.push(markedPartStart);
				}
				lastI = markedPartEnd;
			}
			if(lastI < txt.length){
				unMarkedParts.push(lastI);
				unMarkedParts.push(txt.length);
			}
		}
		const funcCtx = this;
		const drawText = function(parts:number[],color:string){
			funcCtx.ctx.globalCompositeOperation = 'source-over';//default
			for(let p = 0; p < parts.length;p+=2){
				for(let i = parts[p];i<parts[p+1];i++){
					const c = txt[i];
					if(c != ' ')funcCtx.ctx.drawImage(funcCtx.symbolLookup[c].img,x+i*(charSize+spacing),y,charSize,charSize);
				}
			}
			funcCtx.ctx.globalCompositeOperation = "source-atop";
			funcCtx.ctx.fillStyle=color;
			for(let p = 0; p < parts.length;p+=2){
				funcCtx.ctx.fillRect(x+parts[p]*(charSize+spacing),y,(parts[p+1]-parts[p])*(charSize+spacing),charSize);	
			}
			
		};
		if(markedParts)drawText(markedParts,'#9e8600');
		drawText(unMarkedParts,color);
		funcCtx.ctx.globalCompositeOperation = 'source-over';
	}
	draw(){
		this.ctx.clearRect(0,0,this.getAbsW(1),this.getAbsH(1));
		const justrenderingshit = false;
		if(justrenderingshit){
			const txts = [
				'attent1on'
			];
			const x = 20;
			const y = 20;
			const lineSpace = 15;
			const charSize = 50;
			const spacing = Math.round(this.charSizeSpacing * charSize);
			let _y = y;
			this.ctx.globalCompositeOperation = 'source-over';//default
			for(const t of txts){
				let cIdx = 0;
				for(const c of t){
					if(c != ' ')this.ctx.drawImage(this.symbolLookup[c].img,x+cIdx*(charSize+spacing),_y,charSize,charSize);
					cIdx++;
				}
				_y+=lineSpace+charSize;
			}
			this.ctx.globalCompositeOperation = "source-atop";
			this.ctx.fillStyle='white';
			this.ctx.fillRect(0,0,this.getAbsW(1),this.getAbsH(1));	
			
			// this.ctx.globalCompositeOperation = "source-atop";
			// this.ctx.fillStyle='#9e8600';
			// this.ctx.fillRect(x+6*(charSize+spacing),y,charSize,charSize);	
			
			this.ctx.globalCompositeOperation = "destination-over";
			this.ctx.fillStyle='black';
			this.ctx.fillRect(0,0,this.getAbsW(1),this.getAbsH(1));	
			return;
		}
		
		//first draw images
		const darkerWhite = '#858585';
		this.drawCenterText(this.input,this.charSizeInput,this.charPosInput,darkerWhite);
		let headingCharSize = this.charSizeHeadingMin;
		if(this.getTextWidth(this.heading.length,this.charSizeHeadingMin)+2*this.charMinMargin>this.getAbsW(1)){
			headingCharSize = Math.floor((this.getAbsW(1)-this.charMinMargin*2)/(this.charSizeSpacing*(this.heading.length-1)+this.heading.length));	
		}
		this.drawCenterText(this.heading,headingCharSize,this.getAbsH(0.3)-Math.round(0.5*headingCharSize),'white',this.markedHeadingParts);
		let y = this.getAbsH(0.3)+Math.round(0.5*headingCharSize);
		for(const sh of this.subheadings){
			y+=Math.round(this.charSizeSpacing*headingCharSize*2);
			this.drawCenterText(sh,this.charSizeInput,y,darkerWhite);
			y+=Math.round(this.charSizeInput);
		}
		this.ctx.globalCompositeOperation = "destination-over";
		this.ctx.fillStyle='black';
		this.ctx.fillRect(0,0,this.getAbsW(1),this.getAbsH(1));	
	}
}


/**
 * different kinds of resources
 */
abstract class Re{ 
    protected re: any;
    protected state: 0 | 1; //0: still loading, 1: ready
    constructor(url:string,w?:number,h?:number){
        this.setRe(url,w,h);
        this.state = 0;
    }
    protected abstract setRe(url:string,w?:number,h?:number):void;
	abstract getRe():any;
	isReady():boolean {return this.state==1;}
}
class Img extends Re{
    protected re!: HTMLImageElement;
    protected setRe(url:string,w?:number,h?:number):void {
        this.re=new Image(w,h)
        this.re.onload = () => {this.state=1;} //prevent 'this' being ref by other ctxs
        this.re.src=url;
    }
	getRe():HTMLImageElement{return this.re;}
}
class Sound extends Re{
	protected re!: HTMLAudioElement;
	protected setRe(url:string):void{
		this.re=new Audio();
		this.re.oncanplaythrough = () => {this.state = 1;};
		this.re.src = url;
	}	
	getRe():HTMLAudioElement {return this.re;}
} 
interface SoundBank{
	prevC:number; //previously played sound idx
	s:Sound[];//channels
}
/**
 * resource manager
 * - maps filenames without typeinfo to the capsulated resource with a state
 * - maps sounds to channels
 */
class Res{
    private imgs: Map<string,Img>;
	private sounds: Map<string,SoundBank>;
    constructor(){
        this.imgs=new Map<string,Img>();
		this.sounds=new Map<string,SoundBank>();
    }
	
	addSound(url:string,channels:number = 1){
		let s=url.split('/');
		let fn=s[s.length-1].split('.'); 
		if(this.sounds.has(fn[0]))return;
		let cs:Sound[] = [];
		for(let i=0;i<channels;i++)cs.push(new Sound(url));
		this.sounds.set(fn[0],{prevC:-1,s:cs});
	}
	/**
	 * play a sound with the given filename once
	 * @param fn 
	 */
	playSound(fn:string){
		if(!this.sounds.has(fn))throw {desc:'playSound: sound not registered',fn:fn};
		const sb:SoundBank = this.sounds.get(fn) as SoundBank;
		if(sb.prevC < 0){
			sb.prevC = 0;
		}else {
			sb.prevC = (sb.prevC + 1) % sb.s.length;
		}
		const a:HTMLAudioElement = sb.s[sb.prevC].getRe();
		a.currentTime = 0; 
		a.play();
	}
	/**
	 * add an image as urlpath to the resource handler
	 * - when image is loaded, state of the image changes
	 * - a filename(without typeinfo) is assumed to do not contain points
	 * @param url filepath of image
	 * @param w optional width
	 * @param h optional height
	 */
    addImage(url:string,w?:number,h?:number): undefined{
        let s=url.split('/');
		let fn=s[s.length-1].split('.'); 
		if(this.imgs.has(fn[0]))return;

        this.imgs.set(fn[0],new Img(url,w,h));
    }
	/**
	 * get ref to img of file name fn
	 * @param fn file name (without filetype)
	 * @returns imageref or undefined
	 */
	getImg(fn:string):HTMLImageElement|undefined{
		if(!this.imgs.has(fn))throw {desc:'getImg: img to fn not existing',fn:fn};
		return this.imgs.get(fn)?.getRe();
	}
	/**
	 * get the state of the resource manager.
	 * - when there is actually no resource, the state is 0
	 * - otherwise the state equals the relativ amount of loaded resources to the initiated resources
	 * @returns number in range [0,100]
	 */
    getState():number{
        let ready=0;let total = 0;
		total+=this.imgs.size;
        for(const [id,img] of this.imgs)if(img.isReady())ready++;
		for(const [id,channels] of this.sounds){
			total+=channels.s.length;
			for(const s of channels.s)if(s.isReady())ready++;
		}
		return (total < 1)?100:Math.round(ready/total *100);
    }
}
