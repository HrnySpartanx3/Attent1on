"use strict";
function initData(typer) {
    const ppl = new ObjectType('ppl', ['tim', 'paula', 'thomas', 'linda', 'finn', 'richard', 'ronny', 'xqc', 'darren', 'a vtuber', 'an old man', 'a girl', 'a fat boy', 'a disabled', 'an idiot', 'a whore', 'a cunt']);
    const games = new ObjectType('games', ['minecraft', 'pokemon', 'zelda', 'lol', 'backrooms', 'a visual novel', 'outlast', 'silent hill', 'a fps game', 'an eroge', 'an horror game']);
    const mgames = new ObjectType('multiplayergames', ['minecraft', 'gta', 'among us', 'cs', 'lol']);
    const pasttimes = new ObjectType('times', ['yesterday', 'last week', 'ages ago', 'a decade ago']);
    const objs = new ObjectType('objs', ['a clock', 'a pen', 'a bed', 'a tv', 'a shirt', 'a mobile', 'a router', 'a bagpack', 'a table', 'a bottle', 'a cake', 'a keyboard', 'a cigarette', 'a bra', 'a slip', 'an anal plug', 'a baggie', 'a gun', 'a knife', 'a gin bottle', 'your dick']);
    const places = new ObjectType('places', ['the hospital', 'a discounter', 'a park', 'a parking space', 'a library', 'a factory', 'a gas station', 'a warehouse', 'a random place', 'your apartment']);
    const workplaces = new ObjectType('workplaces', ['google', 'microsoft', 'sony', 'a restaurant', 'a school', 'a farm', 'a bar', 'a retail shop', 'a factory', 'a warehouse', 'a call center', 'a brothel', 'twitch']);
    const activity = new ObjectType('actions', ['dancing', 'listening', 'reading', 'programming', 'writing', 'playing', 'sleeping', 'watching', 'traveling', 'crying', 'fucking around', 'vandalizing', 'jerking off', 'fucking', 'coming', 'having sex', 'spying', 'pissing', 'pooping', 'vomitting', 'diying']);
    const food = new ObjectType('food', ['pizza', 'ramen', 'pasta', 'chips', 'sweets', 'nothing important', 'something', 'garbage']);
    const drinks = new ObjectType('drinks', ['water', 'limo', 'cola', 'energy drinks', 'mate', 'vodka', 'something', 'pee']);
    const topics = new ObjectType('topics', ['it stuff', 'fashion', 'physics', 'video games', 'food', 'people', 'the german language', 'having godlike aim', 'women', 'kinks', 'accidents', 'movies', 'success', 'the end of the world', 'how you will die', 'ur erection problems', 'ur dopamine addiction', 'random garbage']);
    const phrases = new ObjectType('phrases', ['i love you', 'hi', 'bye', 'i miss you', 'have fun', 'thanks', 'sorry', 'skibidi', 'gg', 'meh', 'sounds good', 'stop', 'shut your mouth', 'shut up', 'die', 'suck my dick', 'you dont matter', 'kill yourself']);
    //0 slots
    typer.predicateTypes.push([
        new PredicateType(['the sun is shining'], [], [
            new Question(['is the sun shining?'], [])
        ]),
        new PredicateType(['its eight am in the morning'], [], [
            new Question(['is it eight am in the morning?'], [])
        ]),
        new PredicateType(['you hear animals outside'], [], [
            new Question(['do you hear animals outside?'], [])
        ]),
        new PredicateType(['you laugh at a meme'], [], []),
        new PredicateType(['you hear animals outside'], [], [
            new Question(['do you hear animals outside?'], [])
        ]),
        new PredicateType(['your body wants to dance'], [], [
            new Question(['does your body want to dance?'], [])
        ]),
        new PredicateType(['the music hits just right'], [], []),
        new PredicateType(['you design your halloween costume'], [], []),
        new PredicateType(['the ocean looks so nice'], [], []),
        new PredicateType(['you want to become an engineer'], [], [
            new Question(['do you want to become an engineer?'], [])
        ]),
        new PredicateType(['the sky is blue'], [], [
            new Question(['is the sky blue?'], [])
        ]),
        new PredicateType(['those pants feel so good'], [], []),
        new PredicateType(['the sunlight hits your face'], [], []),
        new PredicateType(['you are daydreaming'], [], [
            new Question(['are you daydreaming?'], [])
        ]),
        new PredicateType(['running in the park always feels nice'], [], []),
        new PredicateType(['you got a notification'], [], [
            new Question(['did you get a notification?'], [])
        ]),
        new PredicateType(['the doorbell rings'], [], [
            new Question(['did the doorbell ring?'], [])
        ]),
        new PredicateType(['you visited a friend'], [], [
            new Question(['did you visit a friend?'], [])
        ]),
        new PredicateType(['the drink tastes awesome'], [], []),
        new PredicateType(['the lecture is actually interesting'], [], [
            new Question(['is the lecture interesting for you?'], [])
        ]),
        new PredicateType(['you ask the prof a question'], [], [
            new Question(['did you ask the prof a question?'], [])
        ]),
        new PredicateType(['you took the tram to your office'], [], [
            new Question(['did you take the tram to your office?'], [])
        ]),
        new PredicateType(['your hair looks messy'], [], [
            new Question(['does your hair look messy?'], [])
        ]),
        new PredicateType(['better clean my apartment'], [], []),
        new PredicateType(['strangers look at you'], [], [
            new Question(['do strangers look at you?'], [])
        ]),
        new PredicateType(['the alarm went off too late'], [], [
            new Question(['did the alarm go off too late?'], [])
        ]),
        new PredicateType(['you hear weird noises coming from outside'], [], [
            new Question(['can you hear weird noises coming from outside?'], [])
        ]),
        new PredicateType(['mom just called you'], [], [
            new Question(['did your mom just call you?'], [])
        ]),
        new PredicateType(['you cringe when looking at your past self'], [], []),
        new PredicateType(['you dont want to get up'], [], []),
        new PredicateType(['you are tired'], [], [
            new Question(['are you tired?'], [])
        ]),
        new PredicateType(['the sky is grey'], [], [
            new Question(['is the sky grey?'], [])
        ]),
        new PredicateType(['you arent productive'], [], [
            new Question(['are you productive?'], [])
        ]),
        new PredicateType(['you isolate yourself'], [], [
            new Question(['do you isolate yourself?'], [])
        ]),
        new PredicateType(['you dont get anything you are reading'], [], [
            new Question(['do you have problems understanding what you are reading?'], [])
        ]),
        new PredicateType(['you feel like a burden to society'], [], [
            new Question(['do you feel like a burden to society?'], [])
        ]),
        new PredicateType(['stop fucking around'], [], []),
        new PredicateType(['this fucking shit doesnt make sense'], [], []),
        new PredicateType(['i dont want this shit anymore'], [], []),
        new PredicateType(['video games and porn again'], [], []),
        new PredicateType(['wtf am i doing with my life'], [], []),
        new PredicateType(['pls make it stop'], [], []),
        new PredicateType(['shut up'], [], []),
        new PredicateType(['you feel worthless'], [], [
            new Question(['do you feel worthless?'], [])
        ]),
        new PredicateType(['you stop being social'], [], [
            new Question(['do you stop being social?'], [])
        ]),
        new PredicateType(['i will fail this exam'], [], []),
        new PredicateType(['i want to kill him'], [], [
            new Question(['do you want to kill him?'], [])
        ]),
        new PredicateType(['die bitch'], [], []),
        new PredicateType(['u fucking cunt'], [], []),
        new PredicateType(['thanks for fucking me up'], [], []),
        new PredicateType(['and again and again'], [], []),
        new PredicateType(['you got fired from your job'], [], [
            new Question(['did you get fired from your job?'], [])
        ]),
        new PredicateType(['give me a break'], [], [
            new Question(['do you need a break?'], [])
        ]),
        new PredicateType(['you feel numb'], [], [
            new Question(['do you feel numb?'], [])
        ]),
        new PredicateType(['fuck off'], [], []),
        new PredicateType(['kill yourself haha'], [], []),
        new PredicateType(['why do i have to be alive?'], [], [
            new Question(['do u question ur own existance?'], [])
        ]),
        new PredicateType(['why do i have to be alive?'], [], [
            new Question(['do u question ur own existance?'], [])
        ]),
        new PredicateType(['the bottle kills ur thoughts'], [], []),
        new PredicateType(['why am i still doing this?'], [], []),
        new PredicateType(['end it'], [], []),
        new PredicateType(['i fucked up'], [], []),
        new PredicateType(['i dont deserve to life'], [], []),
        new PredicateType(['just fucking kill yourself'], [], []),
        new PredicateType(['kill yourself'], [], [
            new Question(['do u think about killing yourself?'], [])
        ]),
        new PredicateType(['i am not going to survive this'], [], [
            new Question(['do u realize you wont suvive this?'], [])
        ]),
        new PredicateType(['kill them all'], [], []),
        new PredicateType(['fuck you'], [], []),
        new PredicateType(['this knife could end it all'], [], [
            new Question(['do u have suicidal thoughts?'], [])
        ]),
        new PredicateType(['sexy rope'], [], [
            new Question(['do u think about killing urself?'], [])
        ]),
        new PredicateType(['i want peace'], [], []),
    ]);
    //1 slots
    typer.predicateTypes.push([
        new PredicateType(['everybody admires '], [ppl], [
            new Question(['Who does everybody admire?'], [])
        ]),
        new PredicateType(['', 'is happy'], [ppl], [
            new Question(['who is happy?'], [])
        ]),
        new PredicateType(['', ' is running'], [games], [
            new Question(['whats running?'], [])
        ]),
        new PredicateType(['you are awake since '], [pasttimes], [
            new Question(['since when have you been awake?'], [])
        ]),
        new PredicateType(['theres ', ' which is pretty big'], [objs], [
            new Question(['whats pretty big?'], [])
        ]),
        new PredicateType(['working at ', ' is hard'], [workplaces], [
            new Question(['where is working hard?'], [])
        ]),
        new PredicateType(['', ' is afk'], [ppl], [
            new Question(['who is afk?'], [])
        ]),
        new PredicateType(['', ' rage quited'], [ppl], [
            new Question(['who rage quited?'], [])
        ]),
        new PredicateType(['', ' just crashed'], [games], [
            new Question(['what did just crash?'], [])
        ]),
        new PredicateType(['', ' is pretty difficult'], [games], [
            new Question(['which game is pretty difficult?'], [])
        ]),
        new PredicateType(['there is ', ' with a nice atmosphere'], [places], [
            new Question(['at what place is a nice atmosphere?'], [])
        ]),
        new PredicateType(['', 'isnt looking good'], [ppl], [
            new Question(['who isnt looking good?'], [])
        ]),
        new PredicateType(['', 'got an headache'], [ppl], [
            new Question(['who got an headache?'], [])
        ]),
        new PredicateType(['', 'is sexy'], [ppl], [
            new Question(['who is sexy?'], [])
        ]),
        new PredicateType(['', ' turns you on'], [activity], [
            new Question(['what activity turns you on?'], [])
        ]),
        new PredicateType(['', ' is horny'], [ppl], [
            new Question(['who is horny?'], [])
        ]),
        new PredicateType(['everbody keeps saying ',], [phrases], [
            new Question(['what does everybody say?'], [])
        ]),
        new PredicateType(['', ' tastes like garbage'], [food], [
            new Question(['what tastes like garbage?'], [])
        ]),
        new PredicateType(['', ' fucks up'], [ppl], [
            new Question(['who fucks up?'], [])
        ]),
        new PredicateType(['', ' is still alive'], [ppl], [
            new Question(['who is still alive?'], [])
        ]),
        new PredicateType(['i whish i died '], [pasttimes], [
            new Question(['when did you wish to die?'], [])
        ]),
    ]);
    //2 slots
    typer.predicateTypes.push([
        new PredicateType(['', ' likes '], [ppl, ppl], [
            new Question(['who likes ', '?'], [1]),
            new Question(['who is liked by ', '?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' likes '], [ppl, games], [
            new Question(['who likes ', '?'], [1]),
            new Question(['what does ', ' like?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' is playing '], [ppl, games], [
            new Question(['who is playing ', '?'], [1]),
            new Question(['what is ', ' playing?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' is child of '], [ppl, ppl], [
            new Question(['who is child of ', '?'], [1]),
            new Question(['who is parent of ', '?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' and ', ' are siblings'], [ppl, ppl], [
            new Question(['who is a sibling of ', '?'], [1]),
            new Question(['who is a sibling of ', '?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' and ', ' are friends now'], [ppl, ppl], [
            new Question(['who just became friends with ', '?'], [1]),
            new Question(['who just became friends with ', '?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' just bought '], [ppl, objs], [
            new Question(['who bought ', '?'], [1]),
            new Question(['what did ', ' buy?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' is using '], [ppl, objs], [
            new Question(['who is using ', '?'], [1]),
            new Question(['whats being used by ', '?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' is at ', ' right now'], [ppl, places], [
            new Question(['who is at ', ' right now?'], [1]),
            new Question(['where is ', ' right now?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' is near '], [places, places], [
            new Question(['whats near ', '?'], [1]),
            new Question(['whats near ', '?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' is '], [ppl, activity], [
            new Question(['who is ', '?'], [1]),
            new Question(['whats ', ' doing?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' is in '], [objs, places], [
            new Question(['whats in ', '?'], [1]),
            new Question(['where is ', '?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' is on '], [objs, objs], [
            new Question(['whats on ', '?'], [1]),
            new Question(['whats below ', '?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' is eating '], [ppl, food], [
            new Question(['who is eating ', '?'], [1]),
            new Question(['whats ', ' eating?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' is drinking '], [ppl, drinks], [
            new Question(['who is drinking ', '?'], [1]),
            new Question(['whats ', ' drinking?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' wants to work for '], [ppl, workplaces], [
            new Question(['who wants to work for ', '?'], [1]),
            new Question(['who does ', ' want to work for?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' does some research about '], [ppl, topics], [
            new Question(['who does some research about ', '?'], [1]),
            new Question(['whats ', 's research topic?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' just took over '], [workplaces, workplaces], [
            new Question(['who just took over ', '?'], [1]),
            new Question(['what did ', ' take over?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' ignores '], [ppl, activity], [
            new Question(['who ignores ', '?'], [1]),
            new Question(['what does ', ' ignore?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' hates '], [ppl, activity], [
            new Question(['who hates ', '?'], [1]),
            new Question(['what does ', ' hate?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' hates working for '], [ppl, workplaces], [
            new Question(['who hates working for ', '?'], [1]),
            new Question(['who does ', ' hate working for?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' tortures '], [ppl, ppl], [
            new Question(['who tortures ', '?'], [1]),
            new Question(['who gets tortured by ', '?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' and ', ' died in a car crash'], [ppl, ppl], [
            new Question(['who died besides ', ' in a car crash?'], [1]),
            new Question(['who died besides ', ' in a car crash?'], [0]) //asking for the 1th slot
        ]),
        new PredicateType(['', ' died '], [ppl, pasttimes], [
            new Question(['who died ', '?'], [1]),
            new Question(['when did ', ' die?'], [0]) //asking for the 1th slot
        ])
    ]);
    //3 slots
    typer.predicateTypes.push([
        new PredicateType(['', ' says ', ' to '], [ppl, phrases, ppl], [
            new Question(['who says ', ' to ', '?'], [1, 2]),
            new Question(['what does ', ' say to ', '?'], [0, 2]),
            new Question(['to whom does ', ' say ', ' to?'], [0, 1]) //2th
        ]),
        new PredicateType(['', ' killed ', ' in '], [ppl, ppl, mgames], [
            new Question(['who killed ', ' in ', '?'], [1, 2]),
            new Question(['who did ', ' kill in ', '?'], [0, 2]),
            new Question(['in which game did ', ' kill ', '?'], [0, 1]) //2th
        ]),
        new PredicateType(['', ' gives ', ' '], [ppl, ppl, objs], [
            new Question(['who gives ', ' ', '?'], [1, 2]),
            new Question(['to whom does ', ' give ', '?'], [0, 2]),
            new Question(['what does ', ' give to ', '?'], [0, 1]) //2th
        ]),
        new PredicateType(['', ' visited ', ' '], [ppl, ppl, pasttimes], [
            new Question(['who visited ', ' ', '?'], [1, 2]),
            new Question(['who did ', ' visit ', '?'], [0, 2]),
            new Question(['when did ', ' visit ', '?'], [0, 1]) //2th
        ]),
        new PredicateType(['', ' saw ', ' '], [ppl, ppl, pasttimes], [
            new Question(['who saw ', ' ', '?'], [1, 2]),
            new Question(['who did ', ' see ', '?'], [0, 2]),
            new Question(['when did ', ' see ', '?'], [0, 1]) //2th
        ]),
        new PredicateType(['', ' saw ', ' in '], [ppl, ppl, places], [
            new Question(['who saw ', ' in ', '?'], [1, 2]),
            new Question(['who did ', ' see in ', '?'], [0, 2]),
            new Question(['where did ', ' see ', '?'], [0, 1]) //2th
        ]),
        new PredicateType(['', ' and ', ' are '], [ppl, ppl, activity], [
            new Question(['with whom is ', ' ', '?'], [1, 2]),
            new Question(['with whom is ', ' ', '?'], [0, 2]),
            new Question(['what are ', ' and ', ' doing?'], [0, 1]),
        ]),
        new PredicateType(['', ' uses ', ' for '], [ppl, objs, activity], [
            new Question(['who uses ', ' for ', '?'], [1, 2]),
            new Question(['what does ', ' use for ', '?'], [0, 2]),
            new Question(['what is ', ' using ', ' for?'], [0, 1]),
        ]),
        new PredicateType(['', ' is ', ' in '], [ppl, activity, places], [
            new Question(['who is ', ' in ', '?'], [1, 2]),
            new Question(['what is ', ' doing in ', '?'], [0, 2]),
            new Question(['where is ', ' ', '?'], [0, 1]),
        ]),
        new PredicateType(['', ' thinks about ', ' while '], [ppl, topics, activity], [
            new Question(['who thinks about ', ' while ', '?'], [1, 2]),
            new Question(['what does ', ' think about while ', '?'], [0, 2]),
            new Question(['what is ', ' doing when he thinks about ', '?'], [0, 1]),
        ]),
        new PredicateType(['', ' is teaching ', ' about '], [ppl, ppl, topics], [
            new Question(['who is ', ' in ', '?'], [1, 2]),
            new Question(['what is ', ' doing in ', '?'], [0, 2]),
            new Question(['where is ', ' ', '?'], [0, 1]),
        ]),
        new PredicateType(['', ' poors ', ' on ', 's genitals'], [ppl, drinks, ppl], [
            new Question(['who poors ', ' on ', 's genitals?'], [1, 2]),
            new Question(['what does ', ' poor on ', 's genitals?'], [0, 2]),
            new Question(['who gets wet genitals when ', ' poors ', '?'], [0, 1]),
        ]),
        new PredicateType(['', ' is eating ', ' while sitting on '], [ppl, food, objs], [
            new Question(['who is eating ', ' while sitting on ', '?'], [1, 2]),
            new Question(['what does ', ' eat while sitting on ', '?'], [0, 2]),
            new Question(['on what does ', ' sit while eating ', '?'], [0, 1]),
        ]),
        new PredicateType(['', ' prefers ', ' over '], [ppl, games, activity], [
            new Question(['who prefers ', ' over ', '?'], [1, 2]),
            new Question(['what does ', ' prefer over ', '?'], [0, 2]),
            new Question(['what does ', ' prefer less than ', '?'], [0, 1]),
        ]),
        new PredicateType(['', ' prefers ', ' over '], [ppl, activity, activity], [
            new Question(['who prefers ', ' over ', '?'], [1, 2]),
            new Question(['what does ', ' prefer over ', '?'], [0, 2]),
            new Question(['what does ', ' prefer less than ', '?'], [0, 1]),
        ]),
        new PredicateType(['', ' died in ', ' '], [ppl, places, pasttimes], [
            new Question(['who died in ', ' ', '?'], [1, 2]),
            new Question(['where did ', ' die ', '?'], [0, 2]),
            new Question(['when did ', ' die in ', '?'], [0, 1]),
        ]),
    ]);
}
