
class Sequence{
    txt:string;
    markings:number[];
    constructor(txt:string,markings:number[]){
        this.txt = txt;
        this.markings = markings;
    }
}

class Typer{
    app: TypingGame;

    currSequence:number; //current sequence
    sequences: Sequence[]; //sentences
    answers: string[];  //provided inputs
    solutions: string[]; //correct solutions
    correctSolutionRequired: boolean;
    timer:number;// curr timer

    tutorialPos:number; //current t. slide, starting at 1, if 0 ingame

    predicateTypes:PredicateType[][];//idx refers to amount of slots
    currAmountObjects:number; //amount of gen objects
    currRoundsUntilInc:number; //rounds completed until next increase
    maxAmountObjects:number; //max amount of gen objects
    incAmountObjectsSpeed:number; //required amount of rounds until number of objects increase
    minFactsPick:number; //relative min position to pick objects/predicates from
    minFactsPickMax:number; //relative max value of min picks var 
    maxFactsPick:number; //relative max position to pick objects/predicates from
    incFactsPick:number; //relative increase factor of corr min/max numbers
    insertObjectsMaxTries:number; //max number of tries when filling in remaining slots with picks or with possible others
    currAmountNoise:number;//amount of noise
    currAmountNoiseDiffMax:number;//additional amount diff max
    currRoundsUntilNoiseInc:number;//rounds completed until next noise inc
    incAmountNoiseSpeed:number;//required amount of rounds until number of noise inc

    constructor(app: TypingGame){
        this.app = app;
        this.sequences=[];
        this.currSequence=-1;
        this.timer=0;
        this.answers = [];
        this.solutions = [];
        this.correctSolutionRequired=true;
        
        this.tutorialPos = 1;

        this.currAmountObjects = 1;
        this.maxAmountObjects = 5;
        this.currRoundsUntilInc = 0;
        this.incAmountObjectsSpeed = 5;
        this.minFactsPick = 0;
        this.minFactsPickMax = 0.9;
        this.maxFactsPick = 0.3;
        this.incFactsPick = 0.004;
        this.insertObjectsMaxTries = 100;

        this.currAmountNoise=-4; //having rounds without noise
        this.currAmountNoiseDiffMax=2;
        this.currRoundsUntilNoiseInc=0;
        this.incAmountNoiseSpeed=3;

        this.predicateTypes=[];
    }   

    /**
     * generate the first sequence
     */
    init(){
        initData(this);

        this.correctSolutionRequired=true;
        this.sequences.push(new Sequence('type start and hit enter to start',[5,10]));
        this.solutions = [];
        this.solutions.push('start');
        
        this.updateSequence();
    }

    updateSequence(){
        this.answers=[];
        this.currSequence++;
        const seq = this.sequences[this.currSequence];
        if(this.currSequence < this.sequences.length-1){
            this.timer = setTimeout(()=>this.updateSequence(),seq.txt.length*120);
        }
        this.app.output(seq.txt,[],seq.markings);
    }
    generateEnd(){
        this.sequences.push(new Sequence('i dont have any more questions',[]));
        this.sequences.push(new Sequence('thanks for playing',[]));
        this.solutions.push('');
        this.correctSolutionRequired=true;
        this.currSequence = -1;
        this.updateSequence();
    }
    generateTutorial(){
        this.correctSolutionRequired=true;
        switch(this.tutorialPos){
            case 1:
                this.sequences.push(new Sequence('i will output some facts',[]));
                this.sequences.push(new Sequence('and afterwards will ask you a question about them',[]));
                this.sequences.push(new Sequence('i will give you feedback afterwards',[]));
                this.sequences.push(new Sequence('type ok to continue',[5,7]));
                this.solutions.push('ok');
                break;
            case 2:
                this.sequences.push(new Sequence('yellow marked parts are possible answers',[]));
                this.sequences.push(new Sequence('for example',[]));
                this.sequences.push(new Sequence('pizza tastes awesome',[0,5]));
                this.sequences.push(new Sequence('what tastes awesome?',[]));
                this.solutions.push('pizza');
                break;
            case 3:
                this.sequences.push(new Sequence('there are also facts without marked parts',[]));
                this.sequences.push(new Sequence('questions regarding those facts',[]));
                this.sequences.push(new Sequence('can only be answered with yes or no',[26,29,33,35]));
                this.sequences.push(new Sequence('for example',[]));
                this.sequences.push(new Sequence('pizza tastes awesome',[]));
                this.sequences.push(new Sequence('does pizza taste awesome?',[]));
                this.solutions.push('yes');
                break;
            case 4:
                this.sequences.push(new Sequence('some questions have multiple answers',[]));
                this.sequences.push(new Sequence('already provided answers will show up below',[]));
                this.sequences.push(new Sequence('for example',[]));
                this.sequences.push(new Sequence('paul likes pizza',[0,4,11,16]));
                this.sequences.push(new Sequence('anna likes pizza',[0,4,11,16]));
                this.sequences.push(new Sequence('who likes pizza?',[]));
                this.solutions.push('paul');
                this.solutions.push('anna');
                break;
            case 5:
                this.sequences.push(new Sequence('thats it for the tutorial',[]));
                this.sequences.push(new Sequence('type retry to hear it again or start to play',[5,10,31,36]));
                this.solutions.push('start');
                this.tutorialPos = -1;
                break;
        }
        this.tutorialPos++;
        this.currSequence=-1;
        this.updateSequence();
    }
    generateSequence(){
        //1. predicate types
        let pts:PredicateType[] = [];
        for(const ps of this.predicateTypes){
            for(let i = Math.round((ps.length-1)*this.minFactsPick); i<=Math.round((ps.length-1)*this.maxFactsPick);i++)
                pts.push(ps[i]);
        }
        //2. object types
        let ots:ObjectType[] = [];
        for(const pt of pts){
            for(const ot of pt.slots)
                if(!ots.includes(ot))ots.push(ot);
        }
        //3. objects and 4. predicates
        let vs:[ObjectType,string[]][] = [];//remaining values with the corr objecttype
        for(const ot of ots){
            let _vs:string[] = [];
            for(let i = Math.round((ot.values.length-1)*this.minFactsPick);
             i<=Math.round((ot.values.length-1)*this.maxFactsPick);i++)_vs.push(ot.values[i]);  
            if(_vs.length < 1)continue;
            vs.push([ot,_vs]);
        }
        let objs = 0;
        const objsMax = Math.max(1,getRandR(Math.floor(0.5*this.currAmountObjects),this.currAmountObjects));
        let oPicks:[ObjectType,string][] = [];
        let pPicks:Predicate[] = [];
        while(true){
            if(vs.length < 1 || objs >= objsMax)break;
            const pickOType = getRandR(0,vs.length-1);
            const pickVIdx = getRandR(0,vs[pickOType][1].length-1);
            const oType = vs[pickOType][0];
            const oValue = vs[pickOType][1][pickVIdx]; 
            oPicks.push([oType,oValue]);
            vs[pickOType][1].splice(pickVIdx,1);
            if(vs[pickOType][1].length < 1)vs.splice(pickOType,1);

            let ps:[PredicateType,number][] = [];
            for(const pt of pts){
                for(let slotIdx=0;slotIdx<pt.slots.length;slotIdx++){
                   if(pt.slots[slotIdx] == oType)ps.push([pt,slotIdx]); 
                }
            }
            const pickPType = getRandR(0,ps.length-1);
            const p = ps[pickPType][0].instantiate();
            p.fillSlot(ps[pickPType][1],oValue);
            pPicks.push(p);
            objs+=p.type.slots.length;
        }
        //5. fill remaining
        let remPPicks:Predicate[] = []; //removes
        for(const p of pPicks){
            const slotIdxs = p.remainingSlots();
            //copy object picks without picked
            let _oPicks:[ObjectType,string][] = [];
            let _oPicksRem:[ObjectType,string][] = [];
            const _remOPick = function(type:ObjectType,value:string){
                let i = 0;
                for(i; i < _oPicks.length;){
                    const _oPick = _oPicks[i];
                    if(type == _oPick[0] && value == _oPick[1])break;
                    i++; 
                }
                if(i<_oPicks.length){
                    _oPicksRem.push(_oPicks[i]);
                    _oPicks.splice(i,1);
                }
            };
            for(const oPick of oPicks)_oPicks.push(oPick);
            const filledSlotIdx = p.filledSlots()[0];
            _remOPick(p.type.slots[filledSlotIdx],p.filledValues[filledSlotIdx]);
            _oPicksRem = [];
            //try inserting (picked) objects
            let invalidInsertion = false;
            let validInsertion = false;
            for(let i=0;i<this.insertObjectsMaxTries;i++){
                for(const idx of slotIdxs){
                    let oPvs:string[] = [];
                    for(const o of _oPicks){
                        if(o[0] == p.type.slots[idx])oPvs.push(o[1]);
                    }

                    let v:string;
                    if(oPvs.length > 0){
                        //try picked object
                        v = oPvs[getRandR(0,oPvs.length-1)];
                        _remOPick(p.type.slots[idx],v);
                    }else{
                        //try other possible objects
                        let otherObjects:string[] = [];
                        for(const v of vs){
                            if(v[0] == p.type.slots[idx]){
                                let exclude:string[] = [];
                                for(const r of _oPicksRem)if(r[0] == v[0])exclude.push(r[1]);
                                for(const s of slotIdxs){
                                    if(s == idx)break;
                                    if(p.type.slots[idx] == p.type.slots[s])exclude.push(p.filledValues[s]);
                                }
                                for(const o of v[1])if(!exclude.includes(o))otherObjects.push(o);
                                break;
                            }
                        }
                        if(otherObjects.length < 1){
                            invalidInsertion = true;
                            break;
                        }
                        v = otherObjects[getRandR(0,otherObjects.length-1)];
                    }
                    p.fillSlot(idx,v);
                }
                if(invalidInsertion)continue;
                //check if already existing
                let exists = false;
                for(const q of pPicks){
                    if(q == p) break;
                    if(p.type == q.type){
                        exists=true;
                        for(let sidx =0;sidx<p.filledValues.length;sidx++)if(p.filledValues[sidx] != q.filledValues[sidx]){
                            exists = false;
                            break;
                        }
                        if(exists)break;
                    }
                }
                //revert changes
                if(exists){
                    for(const o of _oPicksRem)_oPicks.push(o);
                    _oPicksRem = [];
                    for(const idx of slotIdxs)p.fillSlot(idx,'');
                }else{
                    validInsertion = true;
                    break;
                }
            }
            if(!validInsertion)remPPicks.push(p);
        }
        //remove non filled predicates
        for(const p of remPPicks){
            pPicks.splice(pPicks.indexOf(p),1);
        }
        //6. 0-slot predicates
        let pt0s:PredicateType[] = [];
        for(const p of pts)if(p.slots.length < 1)pt0s.push(p);
        const noiseAmountMax = Math.max(0,this.currAmountNoise+getRandR(0,this.currAmountNoiseDiffMax));
        const noiseAmount = getRandR(Math.round(0.5*noiseAmountMax),noiseAmountMax);
        let p0Picks:Predicate[] = [];
        for(let i=0;i<noiseAmount;i++){
            p0Picks.push(pt0s[getRandR(0,pt0s.length-1)].instantiate());//noise dupplicates are allowed
        }

        //7. question
        let pQuestion:Predicate|undefined;  //in this case any p
        let pQuestionSlotIdx:number=0; //to be asked for slot idx
        let createPQuestion = true; //in this case non p0 question
        //noise question
        // fewer noise = higher chance to ask for
        // much noise = dont ask for it
        // 50/50 y/n question
        // some p0s dont have a question
        if(p0Picks.length > 0 && getRandR(0,100)<=(1-p0Picks.length/(pPicks.length+p0Picks.length))*100){
            createPQuestion=false;
            if(getRandR(0,100)<50){
                let p0PicksWQuestion:Predicate[] = [];
                for(const p of p0Picks)if(p.type.questions.length>0)p0PicksWQuestion.push(p);
                if(p0PicksWQuestion.length > 0){
                    pQuestion = p0PicksWQuestion[getRandR(0,p0Picks.length-1)];
                    this.solutions.push('yes');
                }else{
                    createPQuestion=true;
                }
            }else{
                let noP0PicksWQuestion:PredicateType[] = [];
                for(const pt0 of pt0s){
                    let isPick = false;
                    if(pt0.questions.length < 1)continue;

                    for(const p0Pick of p0Picks)
                        if(pt0 == p0Pick.type){isPick=true;break;}
                    if(!isPick){
                        noP0PicksWQuestion.push(pt0);
                    }        
                }
                if(noP0PicksWQuestion.length <1){
                    createPQuestion = true;
                }else{
                    pQuestion = noP0PicksWQuestion[getRandR(0,noP0PicksWQuestion.length-1)].instantiate();
                    this.solutions.push('no');
                }
            }
        }
        //predicate question
        if(createPQuestion){
            pQuestion = pPicks[getRandR(0,pPicks.length-1)];
            pQuestionSlotIdx = getRandR(0,pQuestion.type.slots.length-1);
            this.solutions.push(pQuestion.filledValues[pQuestionSlotIdx]);
            for(const p of pPicks){
                if(p == pQuestion)continue;
                if(p.type == pQuestion.type){
                    let possibleSolution = true;
                    for(let i=0; i < p.filledValues.length; i++){
                        if(i == pQuestionSlotIdx)continue; 
                        if(pQuestion.filledValues[i] != p.filledValues[i]){
                            possibleSolution = false;
                            break;
                        }
                    }
                    if(possibleSolution)this.solutions.push(p.filledValues[pQuestionSlotIdx]);
                }
            }
        }
        let question = '';
        if(typeof pQuestion != 'undefined'){
            question = pQuestion.getQuestion(pQuestionSlotIdx);
        }
        //8. sequences
        // mix p0s and ps
        let seq:(Predicate|undefined)[] = [];
        let seqIdxs:number[] = [];
        for(let i=0;i<p0Picks.length+pPicks.length;i++){seqIdxs.push(i);seq.push(undefined);}
        for(const p of pPicks){
            const seqIdxIdx = getRandR(0,seqIdxs.length-1);
            seq[seqIdxs[seqIdxIdx]] = p;
            seqIdxs.splice(seqIdxIdx,1);
        }
        for(let i=0;i<seqIdxs.length;i++)seq[seqIdxs[i]]=p0Picks[i];
        for(const s of seq){
            this.sequences.push(new Sequence((s as Predicate).toString(),(s as Predicate).getFilledParts()));
        }
        this.sequences.push(new Sequence(question,[]));

        this.correctSolutionRequired=false;
        this.currSequence=-1;
        this.updateSequence();
    }
    input(i:string){
        if(this.currSequence != this.sequences.length-1){
            //skip
            clearInterval(this.timer);
            this.updateSequence();
            return;
        }else if(i.length == 0)return; //ignore empty answers
        this.answers.push(i);
        const seq = this.sequences[this.currSequence];
        this.app.output(seq.txt,this.answers,seq.markings);

        //special input
        if(this.tutorialPos == 0 && this.answers[0] == 'retry'){
            this.tutorialPos = 1;
            this.sequences = [];
            this.solutions = [];
            this.generateTutorial();
            return;
        }
        if(this.answers.length < this.solutions.length)return;
        
        //TODO: would be cool if typos are allowed to a certain degree ofc
        let mistakes:string[] = [];
        for(const s of this.solutions){
            if(this.answers.indexOf(s) == -1)mistakes.push(s);
        }
        let cntn = false;
        let answer = false;
        if(mistakes.length > 0){
            if(this.correctSolutionRequired){
                this.currSequence=-1;
                this.updateSequence();
            }else{
                this.sequences = [];
                this.sequences.push(new Sequence('not quite',[]));
                let str:string='';for(const m of mistakes)str+=' '+m;
                this.sequences.push(new Sequence('forgot'+str,[]));
                cntn = true;
            }
        }else {
            cntn = true;
            answer = true;
            this.sequences = [];
            if(!this.correctSolutionRequired){
                this.sequences.push(new Sequence('yes',[]));
            }
        }
        if(cntn){
            this.solutions=[];
            if(this.tutorialPos == 0){
                let endGame = false;
                // sanity
                if(answer){
                    if(this.minFactsPick > 0){
                        this.minFactsPick -= this.incFactsPick;
                        if(this.minFactsPick < 0)this.minFactsPick = 0;
                    }else if(this.maxFactsPick > 0.5){
                        this.maxFactsPick -= this.incFactsPick;
                        if(this.maxFactsPick<0.5)this.maxFactsPick=0.5;
                    }else if(this.maxFactsPick < 0.5){
                        this.maxFactsPick += this.incFactsPick;
                    }else if(this.currAmountObjects == this.maxAmountObjects){
                        endGame = true;
                    }
                }else {
                    if(this.maxFactsPick < 1.0){
                        this.maxFactsPick += this.incFactsPick;
                        if(this.maxFactsPick > 1.0) this.maxFactsPick=1.0;
                    }else if(this.minFactsPick < this.minFactsPickMax){
                        this.minFactsPick += this.incFactsPick;
                        if(this.minFactsPick > this.minFactsPickMax) this.minFactsPick=this.minFactsPickMax;
                    }
                }
                if(endGame){
                    this.generateEnd();
                }else{
                    // regarding objects
                    this.currRoundsUntilInc++;
                    if(this.currRoundsUntilInc == this.incAmountObjectsSpeed){
                        this.currRoundsUntilInc=0;
                        if(this.currAmountObjects < this.maxAmountObjects)this.currAmountObjects++;
                    }
                    // regarding noise
                    this.currRoundsUntilNoiseInc++;
                    if(this.currRoundsUntilNoiseInc == this.incAmountNoiseSpeed){
                        this.currRoundsUntilNoiseInc=0;
                        this.currAmountNoise++;
                    }
                    this.generateSequence();
                }
            }else{
                this.generateTutorial()
            }
            
        }
    }
}

//generic object type of predicates
class ObjectType{
    name:string;
    values:string[];
    constructor(name:string,values:string[]){
        this.name=name;
        this.values=values;
    }
}
//filled predicates
class Predicate{
    type:PredicateType;
    filledValues:string[];
    constructor(type:PredicateType){
        this.type=type;
        this.filledValues=[];
        for(let i=0;i<this.type.slots.length;i++)this.filledValues.push('');
    }
    fillSlot(slotIdx:number,value:string){
        this.filledValues[slotIdx]=value;
    }
    filledSlots():number[]{
        let slotIdxs:number[] = [];
        for(let i=0;i<this.filledValues.length;i++){
            if(this.filledValues[i].length!=0)slotIdxs.push(i);
        }
        return slotIdxs;
    }
    remainingSlots():number[]{
        let slotIdxs:number[] = [];
        for(let i=0;i<this.filledValues.length;i++){
            if(this.filledValues[i].length==0)slotIdxs.push(i);
        }
        return slotIdxs;
    }
    /**
     * get fact text
     */
    toString(){
        if(this.remainingSlots().length > 0)return '';
        let str='';
        for(let i=0;i<this.type.subStrs.length;i++){
            str+=this.type.subStrs[i];
            if(i>=this.filledValues.length)break;
            str+=this.filledValues[i];
        }
        return str;
    }
    /**
     * get arr of idxs referencing start and end of a filled value of the whole string
     * even idxs are start idx, including
     * odd idxs are end idx,excluding
     */
    getFilledParts():number[]{
        if(this.remainingSlots().length > 0)return [];
        let filledParts:number[] = [];
        let lastI = 0;
        for(let i=0;i<this.type.subStrs.length;i++){
            lastI += this.type.subStrs[i].length;
            if(i>=this.filledValues.length)break;
            filledParts.push(lastI);
            lastI+=this.filledValues[i].length;
            filledParts.push(lastI);
        }
        return filledParts;
    }

    /**
     * get question asking for filled value of given slot
     */
    getQuestion(slotIdx:number):string{
        const question = this.type.questions[slotIdx];
        let str='';
        for(let i=0;i<question.subStrs.length;i++){
            str+=question.subStrs[i];
            if(i>=question.slotIdxs.length)break;
            str+=this.filledValues[question.slotIdxs[i]];
        }
        return str;   
    }
    hasQuestions(){//convience fnt
        return this.type.questions.length > 0;
    }

}
//unfilled predicate type
class PredicateType{
    subStrs:string[];//strings between the slots
    slots:ObjectType[];
    questions:Question[];
    constructor(subStrs:string[],slots:ObjectType[],questions:Question[]){
        this.subStrs = subStrs;
        this.slots = slots;
        this.questions=questions;
    }
    instantiate():Predicate{
        return new Predicate(this);
    }  
}

class Question{
    subStrs:string[];
    slotIdxs:number[];
    constructor(subStrs:string[],slotIdxs:number[]){
        this.subStrs=subStrs;
        this.slotIdxs=slotIdxs;
    }
}
